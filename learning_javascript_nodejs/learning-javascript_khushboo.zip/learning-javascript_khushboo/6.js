let petrolPrice = 100; // 100 Rs.
let petrolVolume = 20; // 20 litres
let cost = petrolPrice * petrolVolume;

console.log(cost);
