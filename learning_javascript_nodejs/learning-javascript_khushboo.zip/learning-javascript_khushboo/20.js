// switch case

let i = 3

switch (i) {
    case 1:
        console.log(' i is 1')
        break;

    case 2:
        console.log(' i is 2')
        break;

    case 3:
        console.log(' i is 3')
        break;

    default:
        console.log(' i is none of above...')
        break;
}