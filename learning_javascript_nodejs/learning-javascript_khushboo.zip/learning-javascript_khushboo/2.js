let message = "hello world!";
console.log(message);

// message is a variable.
// "hello world!" is a value.