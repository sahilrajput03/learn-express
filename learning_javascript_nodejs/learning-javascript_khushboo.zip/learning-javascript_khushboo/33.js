let firstname = '44'

console.log(firstname.toLowerCase())
console.log(firstname.toUpperCase())
console.log(firstname.repeat(3))