let i;

for (i = 20; i <= 50; i++) {
  console.log(i);
}
