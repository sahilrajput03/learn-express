 function printOddnumbers(start, end){
 let i;

 for (i = start; i < end; i = i + 2 ){
    console.log (i);
 }

}

printOddnumbers(1,12);