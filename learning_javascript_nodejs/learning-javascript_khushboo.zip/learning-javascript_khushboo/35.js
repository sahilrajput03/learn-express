// do the map function.
let names = ['khushi', 'nisha', 'payal', 'ravina']
let goodnames = names.map((item) => {
    return 'miss. ' + item
})

console.log(names)
console.log(goodnames)
// console.log(goodnames[1])
// goodnames.forEach((item) => {
//     // console.log('Miss.', item)
//     console.log(item)
// })