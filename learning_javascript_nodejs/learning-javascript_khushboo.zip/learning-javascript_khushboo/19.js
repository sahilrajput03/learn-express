let i =1
// while loop
while(i< 20){
    i = i+ 1
    console.log(i)
}