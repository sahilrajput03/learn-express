let oldAge =50;
let rohanAge= 18;

if (rohanAge < oldAge) {
  console.log("You are young");
}else{
    console.log("You are old");
}