// todo: function learning.

function myFunction(){
    console.log("i am myFunction...")
}

myFunction() // calling a function.