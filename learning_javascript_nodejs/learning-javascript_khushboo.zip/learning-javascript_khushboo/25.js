let myPocket = ['purse', 'cap', 'pen', 'eraser']

// console.log( 'myPocket is: ', myPocket)

// for each
myPocket.forEach((item) => {
    console.log('pocket:', item)
})                                                                                                                                                                                                                                                                                                                                              