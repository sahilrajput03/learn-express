console.log("hello world 123");

console.log('car', 'bike')

let a = 'nike'
let b = 'nikon'
let c = 'sony'

console.log(a, b, c)

// console.log(a)
// console.log(b)
// console.log(c)