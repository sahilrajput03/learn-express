// return value of function:

let sum = (a, b, c) => {
    console.log('inside function...')
    return a + b + c
}

let result = sum(2, 4, 6)
console.log(result)