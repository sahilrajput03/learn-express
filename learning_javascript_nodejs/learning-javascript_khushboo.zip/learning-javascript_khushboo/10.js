let i=5
let j = -5
 let k = 10
 let l = i+j+k
// console.log (l)
if (l===10) {
    console.log("true")
}else{
    console.log("false")
}