let star = '*'
// console.log(star.repeat(9))

for (let i = 1; i <= 10 ; i++) {
    // console.log(i)
    console.log(star.repeat(i));
}

for (let i = 10; i >= 1 ; i--) {
    // console.log(i)
    console.log(star.repeat(i));
}
