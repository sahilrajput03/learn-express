// arrow function
let myFunction = (fullName) => {
    console.log("Hello, ", fullName)
}

let multiply = (a, b) => {
    console.log(a * b)
}
multiply(2, 4)

let myName = "Jackson Smith"

// myFunction(myName) // passing value myName to function.