function myFunction(fullName){
    console.log("Hello, ", fullName)
}

let myName = "Tom Harry"

myFunction(myName) // passing value myName to function.