let myPocket = ['purse', 'cap', 'pen', 'eraser']

// accessing array using for-loop
for (let i = 3; i < myPocket.length; i++) {
    let item = myPocket[i]
    console.log('pocket:', item)
}

// accessing array using for-each
// myPocket.forEach((item) => {
//     console.log('pocket:', item)
// })