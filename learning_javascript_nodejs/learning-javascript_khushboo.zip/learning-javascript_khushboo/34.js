// data types:
let a
let b = true
let c = 3
let d = 'India'
let e = {firstname: 'khushi', lastname: 'khan'}
let f = null
let g = 2n ** 53n
let h = Symbol('Sam')

let l = console.log

l('a', typeof a)
l('b', typeof b)
l('c', typeof c)
l('d', typeof d)
l('e', typeof e)
l('f', typeof f)
l('g', typeof g)
l('h', typeof h)