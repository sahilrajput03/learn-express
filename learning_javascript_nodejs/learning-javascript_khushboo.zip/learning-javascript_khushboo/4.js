let passingmarks = 33;
let khushimarks = 3;

if (khushimarks > passingmarks) {
  console.log("i passed the exam");
}
