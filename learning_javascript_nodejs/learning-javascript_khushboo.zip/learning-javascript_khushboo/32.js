let i = 1
max = 10
space = ' '
while (i <= max) {
     let ch = String((i+1)/2)
    console.log(space.repeat(max-i/2) + ch.repeat(i))
    i = i + 2
}