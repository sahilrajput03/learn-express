let a = 2
let b = 4

let multiply = a * b
let divide = a / b

let sum = a + b
let sub = a - b

let l = console.log
l('value of a:', a)
l('value of b:', b)
l('')
l('a multiply by b :', multiply)
l('a divide by b : ', divide)
l('sum of a and b :', sum)
l('subtraction of a and b:', sub)