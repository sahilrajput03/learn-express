let i = -5
// for loop
for (i = -5; i <= 5; i = i+4) {
    console.log(i);
} 