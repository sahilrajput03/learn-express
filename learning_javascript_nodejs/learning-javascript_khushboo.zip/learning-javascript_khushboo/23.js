let myPocket = ['purse','pen', 'eraser']

console.log( 'myPocket is: ', myPocket)

