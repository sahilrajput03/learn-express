let myPocket = ['purse', 'cap', 'pen']

console.log(myPocket[2])
console.log(myPocket.length)