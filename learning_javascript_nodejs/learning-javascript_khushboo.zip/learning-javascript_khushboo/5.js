let passingmarks = 33;
let khushimarks = 3;

if (khushimarks > passingmarks) {
  console.log("congrats, you passed the exam");
}else{
    console.log("please try again");
}