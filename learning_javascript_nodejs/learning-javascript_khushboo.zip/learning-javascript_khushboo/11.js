let i = 10
let j = 20
console.log (i+j)