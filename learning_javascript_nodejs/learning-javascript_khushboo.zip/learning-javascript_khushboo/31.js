let star = '*'
let space = ' '
// console.log(star.repeat(9))

let max = 41 // use only odd number
let i = 1
while (i <= max) {
    console.log(space.repeat(max - i /2 ) + star.repeat(i));
    i = i + 2
}

i = max - 2
while (i >= 1) {
    console.log(space.repeat(max - i / 2) + star.repeat(i));
    i = i - 2
}